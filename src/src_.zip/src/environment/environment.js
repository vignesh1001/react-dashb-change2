/** @format */

// Production Values
// export const API_URL = "https://ctipc.interplay.iterate.ai/api/v1";

// Stage Values
export const API_URL = "https://ctipcstage.interplay.iterate.ai/api/v1";

// Universal
export const GOOGLE_API_KEY =
	"AIzaSyDbcFx5uYf_M6dcNmJcQawKlHp7h4xpZJs&libraries=places";
export const API_KEY = "38Qn_bAKiUq0o4wK9FN0zlwYgthXkA";
