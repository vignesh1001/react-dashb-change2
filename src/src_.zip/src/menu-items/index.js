import reports from "./reports";
import commerce from "./commerce";
import leads from "./leads";
// ===========================|| MENU ITEMS ||=========================== //

const menuItems = {
	items: [leads],
};

export default menuItems;
